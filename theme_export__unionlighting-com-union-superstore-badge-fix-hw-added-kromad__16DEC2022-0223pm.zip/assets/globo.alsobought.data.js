globoRelatedProductsConfig.manualRecommendations = [];
globoRelatedProductsConfig.manualVendors = [];
globoRelatedProductsConfig.manualTags = [];
globoRelatedProductsConfig.manualProductTypes = [];
globoRelatedProductsConfig.manualCollections = [];